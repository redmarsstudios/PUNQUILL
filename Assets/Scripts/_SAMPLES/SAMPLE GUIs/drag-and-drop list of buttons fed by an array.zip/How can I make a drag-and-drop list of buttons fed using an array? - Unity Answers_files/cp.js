(function() {
var ads = [{"title":"Unity 5 Pre-order Beta","link":"http:\/\/unity3d.com\/unity\/beta\/5.0","image":"http:\/\/unity3d.com\/sites\/default\/files\/ads\/2014-10-beta-cross_promo.jpg","target":"_self"},{"title":"Asset Store Birthday Bonanza","link":"https:\/\/www.assetstore.unity3d.com\/en\/#!sale","image":"http:\/\/unity3d.com\/sites\/default\/files\/ads\/2014-10-birthday-cross_promo.jpg","target":"_self"},{"title":"4.6 Open Beta","link":"http:\/\/unity3d.com\/unity\/beta\/4.6","image":"http:\/\/unity3d.com\/sites\/default\/files\/ads\/cross-promo-300x107px.jpg","target":"_self"},{"title":"Start creating today. Pay as you go.","link":"https:\/\/store.unity3d.com\/products\/subscription","image":"http:\/\/unity3d.com\/sites\/default\/files\/ads\/2013-11-subscription-cross_promo.2.jpg","target":"_self"}];
window.onload = serveAd;

function serveAd() {
  var data = pickRandomAd();

  var image = document.createElement('img');
  image.src = data["image"];
  image.alt = data["title"];

  var placeholders = document.querySelectorAll('.unity-ad');
  for (var i = 0; i < placeholders.length; ++i) {
    var placeholder = placeholders[i];
    var ad = buildAd(data, placeholder, image);
    placeholder.appendChild(ad);
  }
}

function trackClick(source, title) {
  _gaq.push(['_trackEvent', 'CP ' + title, source]);
}

function pickRandomAd() {
  return ads[Math.floor(Math.random() * ads.length)];
}

function buildAd(data, placeholder, image) {
  
  var source = placeholder.getAttribute('data-source') || buildDefaultSource();

  var tracked_link = data["link"];
  tracked_link += "?utm_source=" + encodeURIComponent(source);
  tracked_link += "&utm_medium=banner";
  tracked_link += "&utm_campaign=" +  encodeURIComponent("CP " + data["title"]);

  var anchor = document.createElement('a');
  anchor.href = tracked_link;
  anchor.appendChild(image);
  anchor.rel = "nofollow";
  anchor.target = data["target"];
  anchor.onclick = function() {
    trackClick(source, data["title"]);
  };

  return anchor;
}

function buildDefaultSource() {
  var defaultSource = window.location.pathname.substring(1);
  defaultSource = defaultSource.replace(/\//g, "_");
  return defaultSource;
}})();